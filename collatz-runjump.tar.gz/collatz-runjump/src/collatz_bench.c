#include <stdio.h>
#include <stdint.h>
#include <time.h>

#define K 16u
#define TABLE_SIZE (1u<<K)
#define MASK (TABLE_SIZE-1u)
#define SAFE_MIN (1ULL<<(K+1))  // usar la tabla solo si n es bastante mayor que 2^K (evita "saltar" por encima del 1)

uint64_t table_uses = 0, fallback_uses = 0;

uint64_t pow3[64];
uint32_t table_j[TABLE_SIZE];   // numero de pasos "impares" (multiplicaciones) en la ventana
int64_t  table_c[TABLE_SIZE];   // constante aditiva

static inline int ctz64(uint64_t x){ return __builtin_ctzll(x); }

void build_table(){
    pow3[0]=1;
    for(int i=1;i<64;i++) pow3[i]=pow3[i-1]*3;

    for (uint32_t r=1; r<TABLE_SIZE; r+=2){
        uint64_t B = r;
        int j=0, divcount=0;
        while (divcount < (int)K){
            if (B & 1ULL){ B = 3*B+1; j++; }
            else         { B >>= 1; divcount++; }
        }
        __int128 Cbig = (__int128)B * ((uint64_t)1<<K) - (__int128)pow3[j]*r;
        table_j[r] = j;
        table_c[r] = (int64_t)Cbig;
    }
}

// 1) Naive
uint64_t naive(uint64_t n, uint64_t *iters){
    uint64_t steps=0, it=0;
    while(n!=1){ it++; if(n&1) n=3*n+1; else n>>=1; steps++; }
    *iters+=it; return steps;
}
// 2) Acelerado T-map
uint64_t accel(uint64_t n, uint64_t *iters){
    uint64_t steps=0, it=0;
    while(n!=1){
        it++;
        if(n&1){ uint64_t v=3*n+1; int z=ctz64(v); n=v>>z; steps+=z+1; }
        else   { int z=ctz64(n); n>>=z; steps+=z; }
    }
    *iters+=it; return steps;
}
// 3) Salto de racha (formula del usuario), consumiendo tambien los ceros
uint64_t runjump(uint64_t n, uint64_t *iters){
    uint64_t steps=0, it=0;
    while(n!=1){
        it++;
        if(n&1){
            int x=ctz64(n+1);
            uint64_t m=(n+1)>>x;
            uint64_t v=m*pow3[x]-1;
            int z=ctz64(v);
            n=v>>z;
            steps += 2*(uint64_t)x + z;
        } else { int z=ctz64(n); n>>=z; steps+=z; }
    }
    *iters+=it; return steps;
}
// 4) Tabla de ventana fija K (Barina-style) + fallback T-map cerca del final
uint64_t table_method(uint64_t n, uint64_t *iters){
    uint64_t steps=0, it=0;
    while(n!=1){
        it++;
        if(n & 1){
            if (n > SAFE_MIN){
                table_uses++;
                uint32_t r = (uint32_t)(n & MASK);
                uint32_t j = table_j[r];
                int64_t  c = table_c[r];
                __int128 val = (__int128)pow3[j]*n + c;
                uint64_t nn = (uint64_t)(val >> K);
                steps += K + j;      // K divisiones + j multiplicaciones
                int z = ctz64(nn);
                nn >>= z;
                steps += z;
                n = nn;
            } else {
                fallback_uses++;
                uint64_t v=3*n+1; int z=ctz64(v); n=v>>z; steps+=z+1;
            }
        } else { int z=ctz64(n); n>>=z; steps+=z; }
    }
    *iters+=it; return steps;
}

int main(){
    build_table();
    uint64_t N = 20000000ULL;
    uint64_t s1=0,s2=0,s3=0,s4=0, it1=0,it2=0,it3=0,it4=0;

    clock_t t0=clock();
    for(uint64_t n=1;n<=N;n+=2) s1+=naive(n,&it1);
    clock_t t1=clock();
    for(uint64_t n=1;n<=N;n+=2) s2+=accel(n,&it2);
    clock_t t2=clock();
    for(uint64_t n=1;n<=N;n+=2) s3+=runjump(n,&it3);
    clock_t t3=clock();
    for(uint64_t n=1;n<=N;n+=2) s4+=table_method(n,&it4);
    clock_t t4=clock();

    double d1=(double)(t1-t0)/CLOCKS_PER_SEC;
    double d2=(double)(t2-t1)/CLOCKS_PER_SEC;
    double d3=(double)(t3-t2)/CLOCKS_PER_SEC;
    double d4=(double)(t4-t3)/CLOCKS_PER_SEC;

    printf("N = %lu impares verificados (K=%u, tabla de %u entradas)\n\n",(unsigned long)(N/2),K,TABLE_SIZE);
    printf("%-12s %-18s %-18s %-10s\n","Metodo","Pasos elem.","Iteraciones","Tiempo(s)");
    printf("%-12s %-18lu %-18lu %.3f\n","Naive",(unsigned long)s1,(unsigned long)it1,d1);
    printf("%-12s %-18lu %-18lu %.3f\n","Accel(T)",(unsigned long)s2,(unsigned long)it2,d2);
    printf("%-12s %-18lu %-18lu %.3f\n","RunJump",(unsigned long)s3,(unsigned long)it3,d3);
    printf("%-12s %-18lu %-18lu %.3f\n","Tabla-K",(unsigned long)s4,(unsigned long)it4,d4);

    printf("\nConsistencia pasos elementales: %s\n",
        (s1==s2 && s2==s3 && s3==s4) ? "OK, todos coinciden" : "DISCREPANCIA");

    printf("\nSpeedup en tiempo vs naive:\n");
    printf("  Accel(T): %.2fx\n  RunJump:  %.2fx\n  Tabla-K:  %.2fx\n", d1/d2, d1/d3, d1/d4);
    printf("\nUso de tabla vs fallback en Tabla-K: %lu vs %lu (%.1f%% tabla)\n",
        (unsigned long)table_uses, (unsigned long)fallback_uses,
        100.0*table_uses/(table_uses+fallback_uses));
    return 0;
}
