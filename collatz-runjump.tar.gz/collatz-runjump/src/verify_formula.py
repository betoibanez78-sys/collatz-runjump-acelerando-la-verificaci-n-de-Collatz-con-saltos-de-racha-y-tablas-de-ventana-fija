def v2(n):
    x = 0
    while n % 2 == 0:
        n //= 2
        x += 1
    return x

def collatz_odd_step(n):
    # un paso "3n+1 luego dividir por 2 una vez" (no el shortcut completo)
    return (3*n+1)//2

# Verificar la formula: n impar, n+1 = m*2^x  =>  tras aplicar x veces
# el paso (3n+1)/2, se llega a m*3^x - 1
errors = 0
for n in range(1, 200000, 2):
    x = v2(n+1)
    m = (n+1) >> x
    # aplicar x pasos reales
    cur = n
    for _ in range(x):
        cur = collatz_odd_step(cur)
    predicted = m * (3**x) - 1
    if cur != predicted:
        errors += 1
        print("MISMATCH", n, x, m, cur, predicted)

print("errores:", errors, "de", 100000, "numeros probados")
