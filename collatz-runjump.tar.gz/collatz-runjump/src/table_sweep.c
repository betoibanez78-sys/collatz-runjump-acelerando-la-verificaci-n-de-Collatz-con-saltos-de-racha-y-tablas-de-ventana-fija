#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

uint64_t pow3[64];
static inline int ctz64(uint64_t x){ return __builtin_ctzll(x); }

uint64_t run_table_method(uint64_t N, unsigned K, double *out_time, uint64_t *out_iters, double *build_time_out, uint64_t *table_uses){
    uint64_t TABLE_SIZE = 1ULL<<K;
    uint64_t MASK = TABLE_SIZE-1;
    uint64_t SAFE_MIN = 1024ULL; // margen minimo fijo, igual para todos los K (posible sesgo menor cerca de la cola, no afecta la convergencia)

    uint32_t *table_j = malloc(TABLE_SIZE*sizeof(uint32_t));
    int64_t  *table_c = malloc(TABLE_SIZE*sizeof(int64_t));

    clock_t tb0 = clock();
    for (uint64_t r=1; r<TABLE_SIZE; r+=2){
        uint64_t B = r;
        int j=0, divcount=0;
        while (divcount < (int)K){
            if (B & 1ULL){ B = 3*B+1; j++; }
            else         { B >>= 1; divcount++; }
        }
        __int128 Cbig = (__int128)B * (uint64_t)TABLE_SIZE - (__int128)pow3[j]*r;
        table_j[r] = j;
        table_c[r] = (int64_t)Cbig;
    }
    clock_t tb1 = clock();
    *build_time_out = (double)(tb1-tb0)/CLOCKS_PER_SEC;

    uint64_t steps=0, iters=0, tu=0;
    clock_t t0 = clock();
    for (uint64_t start=1; start<=N; start+=2){
        uint64_t n = start;
        while (n != 1){
            iters++;
            if (n & 1){
                if (n > SAFE_MIN){
                    tu++;
                    uint64_t r = n & MASK;
                    uint32_t j = table_j[r];
                    int64_t  c = table_c[r];
                    __int128 val = (__int128)pow3[j]*n + c;
                    uint64_t nn = (uint64_t)(val >> K);
                    steps += K + j;
                    int z = ctz64(nn);
                    nn >>= z;
                    steps += z;
                    n = nn;
                } else {
                    uint64_t v=3*n+1; int z=ctz64(v); n=v>>z; steps+=z+1;
                }
            } else { int z=ctz64(n); n>>=z; steps+=z; }
        }
    }
    clock_t t1 = clock();
    *out_time = (double)(t1-t0)/CLOCKS_PER_SEC;
    *out_iters = iters;
    *table_uses = tu;

    free(table_j); free(table_c);
    return steps;
}

int main(){
    pow3[0]=1;
    for(int i=1;i<64;i++) pow3[i]=pow3[i-1]*3;

    uint64_t N = 40000000ULL;
    unsigned Ks[] = {12,14,16,18,20,22,24};
    int nk = sizeof(Ks)/sizeof(Ks[0]);

    printf("N=%lu impares verificados. Barrido de K:\n\n", (unsigned long)(N/2));
    printf("%-4s %-10s %-10s %-14s %-10s %-8s %-8s\n","K","TablaMB","Build(s)","Iteraciones","Tiempo(s)","%tabla","Speedup");

    uint64_t s_ref=0; double t_ref=0;
    for(int i=0;i<nk;i++){
        unsigned K = Ks[i];
        double t, bt; uint64_t it, tu;
        uint64_t s = run_table_method(N, K, &t, &it, &bt, &tu);
        if (i==0){ s_ref = s; t_ref = t; }
        double mb = (double)((1ULL<<K)*(sizeof(uint32_t)+sizeof(int64_t)))/1e6;
        double pct = 100.0*tu/it;
        printf("%-4u %-10.2f %-10.3f %-14lu %-10.3f %-8.1f %.2fx",
            K, mb, bt, (unsigned long)it, t, pct, t_ref/t);
        if (s != s_ref) printf("  *** DISCREPANCIA ***");
        printf("\n");
    }
    return 0;
}
