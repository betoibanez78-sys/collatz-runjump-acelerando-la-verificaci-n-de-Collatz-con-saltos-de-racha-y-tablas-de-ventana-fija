"""
Verifica de forma puntual que 2^k - 1 converge a 1 bajo Collatz, para k por
encima del record de verificacion exhaustiva (2^71, Barina 2025).

Usa la formula de salto de racha: para estos numeros m=1 siempre (ya que
n+1 = 2^k exactamente), asi que el primer salto es 3^k - 1 calculado de un
tiron, sin ninguna multiplicacion intermedia.

Uso:
    python3 verify_extreme.py            # corre un barrido por defecto
    python3 verify_extreme.py 500000     # corre un k especifico
"""
import sys
import time


def v2(n):
    """Valoracion 2-adica de n (numero de ceros finales en binario)."""
    return (n & -n).bit_length() - 1


def verify(n0, max_steps=10_000_000):
    """Aplica el mapa acelerado (salto de racha + division de ceros) hasta
    llegar a 1 o agotar max_steps. Devuelve (convergio, pasos, bits_maximos)."""
    n = n0
    steps = 0
    max_bits = n.bit_length()
    while n != 1:
        if n & 1:
            x = v2(n + 1)
            m = (n + 1) >> x
            n = m * pow(3, x) - 1
        else:
            z = v2(n)
            n >>= z
        steps += 1
        max_bits = max(max_bits, n.bit_length())
        if steps > max_steps:
            return False, steps, max_bits
    return True, steps, max_bits


def run(k):
    n0 = (1 << k) - 1
    t0 = time.time()
    ok, steps, max_bits = verify(n0)
    dt = time.time() - t0
    status = "converge a 1" if ok else "NO convergio dentro del limite de pasos"
    print(f"k={k:>8}  digitos~{len(str(n0)):>8}  pasos={steps:>9}  "
          f"max_bits={max_bits:>9}  tiempo={dt:>8.3f}s  {status}")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        run(int(sys.argv[1]))
    else:
        # Barrido por defecto: desde justo encima del record hasta 300k bits.
        # k=300000 tarda ~30s; valores mayores crecen aprox. cuadraticamente.
        for k in [72, 100, 200, 500, 1000, 5000, 10000, 50000, 100000, 300000]:
            run(k)
