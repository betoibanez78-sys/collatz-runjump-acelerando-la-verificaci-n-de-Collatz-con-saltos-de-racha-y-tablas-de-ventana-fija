# collatz-runjump

![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Language: C](https://img.shields.io/badge/C-99%2B-00599C?logo=c)
![Language: Python](https://img.shields.io/badge/Python-3.8%2B-3776AB?logo=python&logoColor=white)
![Status: exploratorio](https://img.shields.io/badge/status-exploratorio-yellow)

Exploración computacional de aceleradores para la conjetura de Collatz (3n+1),
centrada en una fórmula de salto cerrado para "rachas" de bits y en tablas de
ventana fija tipo Barina (2021/2025).

**No es una prueba de la conjetura ni una extensión del récord de verificación
exhaustiva** (récord actual: todo n < 2^71, David Barina, enero 2025, con años
de cómputo dedicado). Esto es una exploración de técnicas de aceleración y
verificación puntual de casos estructuralmente extremos.

## Índice

- [1. La fórmula de salto de racha](#1-la-fórmula-de-salto-de-racha)
- [2. Comparación de métodos (benchmark)](#2-comparación-de-métodos-benchmark)
- [3. Verificación puntual de "rachas malas" (2^k − 1)](#3-verificación-puntual-de-rachas-malas-2k--1)
- [Estructura del repo](#estructura-del-repo)
- [Cómo correr](#cómo-correr)
- [Contribuir](#contribuir)
- [Licencia](#licencia)

## 1. La fórmula de salto de racha

Para todo entero impar `n`, si `n+1 = m·2^x` (es decir, `x = v2(n+1)`, la
valoración 2-ádica; equivalentemente, `x` es el número de unos consecutivos al
final de `n` en binario), entonces aplicar `x` veces seguidas el paso acelerado
`(3n+1)/2` da, en una sola operación cerrada:

```
n_nuevo = m·3^x − 1
```

Verificado algebraicamente (por inducción, ver `src/verify_formula.py`) y
computacionalmente sobre cientos de miles de casos sin excepciones.

### Por qué funciona

Si `n = m·2^x − 1`, entonces `f(n) = (3n+1)/2 = 3m·2^(x−1) − 1`, que tiene la
misma forma con `x` reducido en 1. Iterando `x` veces se llega a
`m·3^x·2^0 − 1 = m·3^x − 1`. Cada uno de los `x` números intermedios es impar
(se demuestra que `n_i + 1 = m·3^i·2^(x−i)` es par mientras `i < x`), así que
la fórmula corresponde exactamente a `x` pasos legítimos de Collatz.

## 2. Comparación de métodos (benchmark)

`src/collatz_bench.c` compara cuatro estrategias verificando ~10 millones de
impares, contrastando el conteo total de pasos elementales entre todas (deben
coincidir exactamente — es la comprobación de corrección):

| Método | Iteraciones de bucle | Tiempo | Speedup vs. naive |
|---|---|---|---|
| Naive (un paso a la vez) | ~1.69 mil M | ~2.9 s | 1.0x |
| T-map acelerado estándar | ~563 M | ~1.1 s | ~2.7x |
| Salto de racha (fórmula de este repo) | ~282 M | ~1.6 s | ~1.9x |
| Tabla de ventana fija (K=16 bits) | ~354–420 M | ~0.9–1.5 s | ~2.9–3.1x |

**Hallazgo principal:** el salto de racha reduce las iteraciones exactamente a
la mitad respecto al T-map (consistente con que la longitud esperada de racha
es E[x]=2), pero en tiempo real de reloj es *más lento* que el T-map simple:
la multiplicación por `3^x` (variable, con tabla de potencias) cuesta más que
el `3n+1` de multiplicador fijo, que el compilador reduce a shift+suma.

La tabla de ventana fija (que precomputa, para cada residuo de K bits, la
transformación afín `(a·n+c)/2^K` resultante de K pasos elementales) gana en
la práctica porque, a igual costo por iteración, procesa muchos más bits de
golpe. `src/table_sweep.c`
barre el tamaño K de la tabla y muestra el punto óptimo alrededor de K≈16
(tabla de ~0.8 MB, cabe en caché L2); para K≥20 el tiempo empeora por fallos
de caché pese a seguir bajando el número de iteraciones.

## 3. Verificación puntual de "rachas malas" (2^k − 1)

Los números `2^k − 1` son el caso extremo de racha (una racha de `k` unos
consecutivos), y para ellos la fórmula de este repo es óptima: como `m=1`
siempre, el primer salto es literalmente `3^k − 1` calculado de un tirón, sin
ninguna multiplicación intermedia.

`src/verify_extreme.py` verifica, usando enteros de precisión arbitraria,
que `2^k − 1` converge a 1 para valores de `k` muy por encima del récord
verificado (2^71 ≈ 21 dígitos decimales):

| k | dígitos (~) | pasos acelerados | tiempo | resultado |
|---|---|---|---|---|
| 72–10.000 | hasta 3.010 | 264–38.196 | <0.05 s | converge |
| 50.000 | 15.050 | 189.740 | 0.90 s | converge |
| 100.000 | 30.100 | 381.396 | 3.57 s | converge |
| 300.000 | 90.300 | 1.142.076 | 32.3 s | converge |

Esto **no** es una extensión del récord de verificación exhaustiva (que exige
probar *todos* los números hasta un límite, no casos puntuales), pero sí
confirma que la familia señalada en la literatura como "peor comportada"
estructuralmente no muestra ningún signo de anomalía incluso a escalas miles
de veces mayores que el récord general.

## Estructura del repo

```
src/
  collatz_bench.c      # comparacion de los 4 metodos + validacion cruzada
  table_sweep.c         # barrido de tamaño de tabla K (efecto de cache)
  verify_extreme.py      # verificacion puntual de 2^k-1 para k grande
  verify_formula.py       # prueba computacional de la formula de salto de racha
```

## Cómo correr

```bash
gcc -O2 -o collatz_bench src/collatz_bench.c && ./collatz_bench
gcc -O2 -o table_sweep src/table_sweep.c && ./table_sweep
python3 src/verify_formula.py
python3 src/verify_extreme.py
```

## Contribuir

Ideas bienvenidas, sobre todo en estas líneas:

- Otras familias "sospechosas" además de `2^k − 1` (por ejemplo residuos
  específicos mod 3, o candidatos de ciclo no trivial).
- Paralelización (hilos, SIMD) de la tabla de ventana fija.
- Una versión en C con enteros de precisión arbitraria (GMP) del verificador
  puntual, para empujar `k` más allá de lo que da Python puro.
- Correcciones si encuentran un error en la derivación o en el código.

Para proponer un cambio: abrí un issue describiendo qué probaste y qué
resultado obtuviste (con benchmark reproducible si aplica), o mandá un pull
request directo si ya tenés el código.

## Licencia

MIT. Úsese, adáptese y compártase libremente.
